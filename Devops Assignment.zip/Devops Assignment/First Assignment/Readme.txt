Important notes before the code execution:
============================================

The Script is written with terraform version hashicorp/aws v3.53.0

Code References used from https://registry.terraform.io/

IAM Role Policy References used from https://docs.aws.amazon.com 

The script used programatic IAM user with AWS Managed Policy "AdministratorAccess" to configure entire Delivery Outcomes

This Programatic user used aws access key & secret access key configured with terraform using environment variables,
any new execution can also be done by configuring desired credentials file with environment variables in local system or by using export 
utility inside terraform.  

Provider Configurations are in file named "provider.tf"

Entire Delivery Assignment Configured with the single file named "main.tf", to be executed, to have Desired Delivery Outcomes

EC2 systems will be provisioned using the keyfiles named "apptier.ppk" & "webtier.ppk", in case of accessing the
provisioned ec2 systems, please create same named key in aws console before script execution.

All the Desired Outcomes will be configured within 10-15 minutes of execution of main.tf

Destruction of all spinned up resources will be finished within 10-15 minutes of execution of # terraform apply -destroy