The Zip Folder Contains Sample Application along with DockerFile & JenkinsFile.

he script used programatic IAM user with AWS Managed Policy "AdministratorAccess" to configure entire Delivery Outcomes

docker eksctl & kubectl etc are the command line utility used 

Upon executing Pipeline from jenkins everything is getting provisioned.